--
-- PostgreSQL database dump
--

-- Dumped from database version 9.4.7
-- Dumped by pg_dump version 9.4.7
-- Started on 2016-05-03 15:18:34 ART

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

DROP DATABASE "JBossBank";
--
-- TOC entry 2965 (class 1262 OID 16385)
-- Name: JBossBank; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "JBossBank" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE "JBossBank" OWNER TO postgres;

\connect "JBossBank"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 6 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- TOC entry 2966 (class 0 OID 0)
-- Dependencies: 6
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- TOC entry 1 (class 3079 OID 12810)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2968 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 173 (class 1259 OID 16386)
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE accounts (
    accountid integer NOT NULL,
    customerref integer,
    accountbalance double precision,
    accounttype integer
);


ALTER TABLE accounts OWNER TO postgres;

--
-- TOC entry 174 (class 1259 OID 16391)
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE customers (
    customerid integer NOT NULL,
    customername text,
    customerlastname text,
    customerlevel integer
);


ALTER TABLE customers OWNER TO postgres;

--
-- TOC entry 175 (class 1259 OID 16410)
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE transactions (
    transactionid integer NOT NULL,
    clientid integer,
    amount double precision,
    accountid integer
);


ALTER TABLE transactions OWNER TO postgres;

--
-- TOC entry 2958 (class 0 OID 16386)
-- Dependencies: 173
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO accounts (accountid, customerref, accountbalance, accounttype) VALUES (111, 1, 200, 1);
INSERT INTO accounts (accountid, customerref, accountbalance, accounttype) VALUES (112, 1, -20, 1);
INSERT INTO accounts (accountid, customerref, accountbalance, accounttype) VALUES (211, 2, 430, 2);


--
-- TOC entry 2959 (class 0 OID 16391)
-- Dependencies: 174
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO customers (customerid, customername, customerlastname, customerlevel) VALUES (1, 'Pablo', 'Szuster', 1);
INSERT INTO customers (customerid, customername, customerlastname, customerlevel) VALUES (2, 'Juan', 'Perez', 2);
INSERT INTO customers (customerid, customername, customerlastname, customerlevel) VALUES (3, 'Alfredo', 'Ramirez', 3);


--
-- TOC entry 2960 (class 0 OID 16410)
-- Dependencies: 175
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO transactions (transactionid, clientid, amount, accountid) VALUES (111, 1, 200, 112);
INSERT INTO transactions (transactionid, clientid, amount, accountid) VALUES (222, 2, -200, 113);
INSERT INTO transactions (transactionid, clientid, amount, accountid) VALUES (333, 3, 50, 211);


--
-- TOC entry 2842 (class 2606 OID 16390)
-- Name: accountID; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY accounts
    ADD CONSTRAINT "accountID" PRIMARY KEY (accountid);


--
-- TOC entry 2845 (class 2606 OID 16398)
-- Name: customerID; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY customers
    ADD CONSTRAINT "customerID" PRIMARY KEY (customerid);


--
-- TOC entry 2847 (class 2606 OID 16414)
-- Name: transactionid; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY transactions
    ADD CONSTRAINT transactionid PRIMARY KEY (transactionid);


--
-- TOC entry 2843 (class 1259 OID 16404)
-- Name: fki_customerID; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "fki_customerID" ON accounts USING btree (customerref);


--
-- TOC entry 2848 (class 2606 OID 16405)
-- Name: customerIDFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY accounts
    ADD CONSTRAINT "customerIDFK" FOREIGN KEY (customerref) REFERENCES customers(customerid);


--
-- TOC entry 2967 (class 0 OID 0)
-- Dependencies: 6
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2016-05-03 15:18:34 ART

--
-- PostgreSQL database dump complete
--


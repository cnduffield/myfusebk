package com.jbossbank;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.camel.dataformat.bindy.annotation.CsvRecord;
import org.apache.camel.dataformat.bindy.annotation.DataField;


/**
 * The persistent class for the transactions database table.
 * 
 */
@CsvRecord( separator = ";" ,skipFirstLine = true )
@Entity
@Table(name="transactions")
@NamedQuery(name="Transaction.findAll", query="SELECT t FROM Transaction t")
public class Transaction implements Serializable {
	private static final long serialVersionUID = 1L;

	@DataField(pos = 1)
	@Id
	private Integer transactionid;

	@DataField(pos = 2)
	private Integer accountid;

	@DataField(pos = 3)
	private double amount;

	@DataField(pos = 4)
	private Integer clientid;

	public Transaction() {
	}

	public Integer getTransactionid() {
		return this.transactionid;
	}

	public void setTransactionid(Integer transactionid) {
		this.transactionid = transactionid;
	}

	public Integer getAccountid() {
		return this.accountid;
	}

	public void setAccountid(Integer accountid) {
		this.accountid = accountid;
	}

	public double getAmount() {
		return this.amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Integer getClientid() {
		return this.clientid;
	}

	public void setClientid(Integer clientid) {
		this.clientid = clientid;
	}

}